	 <section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url('<?php echo base_url('').'assets/'?>images/master-slide-01.jpg');">
		  
    </section>

    <section class="blog p-t-94 p-b-65" style="margin-top: -59px;">
        <div class="container">
          <div class="sec-title"style="padding-bottom:3px">
						<h3 class="m-text26 t-center"style="margin-top: 3%;">
							Struktur Organisasi
						</h3>
		 		 </div>
				
       </div>
    </section>

		<section class="blog p-t-94 p-b-65" style="margin-top: -139px;">
        <div class="container">
          <div class="sec-title"style="padding-bottom:3px">
						<h3 class="m-text26 t-center"style="margin-top: 3%;">
						<img src="<?php echo base_url('').'assets/'?>images/bagan.png" width="75%">
						</h3>
		 		 </div>					
       </div>
    </section>
		<section class="blog bgwhite p-t-94 p-b-65" style="margin-top: -3%;">
		<div class="container">
			<div class="row">
				<div class="col-sm-10 col-md-4 p-b-30 m-l-r-auto">
					<!-- Block3 -->
					<div class="block3">
						<a href="blog-detail.html" class="block3-img dis-block hov-img-zoom">
							<img src="<?php echo base_url('').'assets/'?>images/shop-item-09.jpg" alt="IMG-BLOG">
						</a>
					</div>
				</div>

				<div class="col-sm-10 col-md-4 p-b-30 m-l-r-auto">
					<!-- Block3 -->
					<div class="block3">
						<a href="blog-detail.html" class="block3-img dis-block hov-img-zoom">
							<img src="<?php echo base_url('').'assets/'?>images/shop-item-09.jpg" alt="IMG-BLOG">
						</a>
					</div>
				</div>

				<div class="col-sm-10 col-md-4 p-b-30 m-l-r-auto">
					<!-- Block3 -->
					<div class="block3">
						<a href="blog-detail.html" class="block3-img dis-block hov-img-zoom">
							<img src="<?php echo base_url('').'assets/'?>images/shop-item-09.jpg" alt="IMG-BLOG">
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>