 <section class="bgwhite p-t-60">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-lg-9 p-b-75">
					<div class="p-r-50 p-r-0-lg">
						<!-- item blog -->
						<div class="item-blog p-b-80">
							<a href="blog-detail.html" class="item-blog-img pos-relative dis-block hov-img-zoom">
								<img src="<?php echo base_url('').'assets/'?>images/blog-04.jpg" alt="IMG-BLOG">
                                
								<span class="item-blog-date dis-block flex-c-m pos1 size17 bg4 s-text1">
									28 Dec, 2018
								</span>
							</a>

							<div class="item-blog-txt p-t-33">
								<h4 class="p-b-11">
									<a href="blog-detail.html" class="m-text24">
										Berita 1
									</a>
								</h4>
								<p class="p-b-12" style="text-align: justify;">
									Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce eget dictum tortor. Donec dictum vitae sapien eu varius  Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce eget dictum tortor. Donec dictum vitae sapien eu varius  Donec dictum vitae sapien eu varius                                    
								</p>

							
                                <button class="button1 s-text20" style="margin-top: 19px;" onclick="window.location.href='<?php echo base_url('Beritadetail')?>'"><span>Selengkapnya </span></button>
							
							</div>
						</div>

						<!-- item blog -->
						<div class="item-blog p-b-80">
							<a href="blog-detail.html" class="item-blog-img pos-relative dis-block hov-img-zoom">
								<img src="<?php echo base_url('').'assets/'?>images/blog-04.jpg" alt="IMG-BLOG">

								<span class="item-blog-date dis-block flex-c-m pos1 size17 bg4 s-text1">
									26 Dec, 2018
								</span>
							</a>

							<div class="item-blog-txt p-t-33">
								<h4 class="p-b-11">
									<a href="blog-detail.html" class="m-text24">
                                    Berita 1
									</a>
								</h4>
								<p class="p-b-12" style="text-align: justify;">
									Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce eget dictum tortor. Donec dictum vitae sapien eu varius
								</p>

								
                                <button class="button1 s-text20" style="margin-top: 19px;" onclick="window.location.href='<?php echo base_url('Beritadetail')?>'"><span>Selengkapnya </span></button>								
							</div>
						</div>

						<div class="item-blog p-b-80">
							<a href="blog-detail.html" class="item-blog-img pos-relative dis-block hov-img-zoom">
								<img src="<?php echo base_url('').'assets/'?>images/blog-04.jpg" alt="IMG-BLOG">

								<span class="item-blog-date dis-block flex-c-m pos1 size17 bg4 s-text1">
									22 Dec, 2018
								</span>
							</a>

							<div class="item-blog-txt p-t-33">
								<h4 class="p-b-11">
									<a href="blog-detail.html" class="m-text24">
                                    Berita 1
									</a>
								</h4>

								<p class="p-b-12" style="text-align: justify;">
								   Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce eget dictum tortor. Donec dictum vitae sapien eu varius FSWDFSDSSSSSSSSSSSSS Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce eget dictum tortor. Donec dictum vitae sapien eu varius FSWDFSDSSSSSSSSSSSSS
								</p>

								
                                <button class="button1 s-text20" style="margin-top: 19px;" onclick="window.location.href='<?php echo base_url('Beritadetail')?>'"><span>Selengkapnya </span></button>
								
							</div>
						</div>
					</div>
	
					<div class="pagination flex-m flex-w p-r-50">
						<a href="#" class="item-pagination flex-c-m trans-0-4 active-pagination">1</a>
						<a href="#" class="item-pagination flex-c-m trans-0-4">2</a>
					</div>
				</div>

				<div class="col-md-4 col-lg-3 p-b-75">
					<div class="rightbar">
					
						<div class="pos-relative bo11 of-hidden">
							<input class="s-text7 size16 p-l-23 p-r-50" type="text" name="search-product" placeholder="Search">

							<button class="flex-c-m size5 ab-r-m color1 color0-hov trans-0-4">
								<i class="fs-13 fa fa-search" aria-hidden="true"></i>
							</button>
						</div>
						<!-- Featured Products -->
						<h4 class="m-text23 p-t-65 p-b-34">
							Berita
						</h4>

						<ul class="bgwhite">
							<li class="flex-w p-b-20">
								<a href="product-detail.html" class="dis-block wrap-pic-w w-size22 m-r-20 trans-0-4 hov4">								
                                    <img src="<?php echo base_url('').'assets/'?>images/item-16.jpg" style="height: 74%;">
								</a>

								<div class="w-size23 p-t-5">
									<a href="product-detail.html" class="s-text20">
									     <strong>Judul</strong>	
									</a>

									<span class="dis-block s-text17 p-t-6">
									    <i class="fa fa-calendar"> 26 Feb 2019 </i>
									</span>
								</div>
							</li>

							<li class="flex-w p-b-20">
								<a href="product-detail.html" class="dis-block wrap-pic-w w-size22 m-r-20 trans-0-4 hov4">
                                 <img src="<?php echo base_url('').'assets/'?>images/item-16.jpg"  style="height: 74%;">
								</a>

								<div class="w-size23 p-t-5">
									<a href="product-detail.html" class="s-text20">
                                      <strong>Judul</strong>	
									</a>

									<span class="dis-block s-text17 p-t-6">
									    <i class="fa fa-calendar"> 26 Feb 2019 </i>
									</span>
								</div>
							</li>

							<li class="flex-w p-b-20">
								<a href="product-detail.html" class="dis-block wrap-pic-w w-size22 m-r-20 trans-0-4 hov4">
                                   <img src="<?php echo base_url('').'assets/'?>images/item-16.jpg"  style="height: 74%;">
								</a>

								<div class="w-size23 p-t-5">
									<a href="product-detail.html" class="s-text20">
                                      <strong>Judul</strong>	
									</a>

									<span class="dis-block s-text17 p-t-6">
									    <i class="fa fa-calendar"> 26 Feb 2019 </i>
									</span>
								</div>
							</li>

							<li class="flex-w p-b-20">
								<a href="product-detail.html" class="dis-block wrap-pic-w w-size22 m-r-20 trans-0-4 hov4">
                                 <img src="<?php echo base_url('').'assets/'?>images/item-16.jpg"  style="height: 74%;">
								</a>

								<div class="w-size23 p-t-5">
									<a href="product-detail.html" class="s-text20">
                                         <strong>Judul</strong>	
									</a>

									<span class="dis-block s-text17 p-t-6">
									    <i class="fa fa-calendar"> 26 Feb 2019 </i>
									</span>
								</div>
							</li>

							<li class="flex-w p-b-20">
								<a href="product-detail.html" class="dis-block wrap-pic-w w-size22 m-r-20 trans-0-4 hov4">
                                 <img src="<?php echo base_url('').'assets/'?>images/item-16.jpg"  style="height: 74%;">
								</a>

								<div class="w-size23 p-t-5">
									<a href="product-detail.html" class="s-text20">
                                       <strong>Judul</strong>	
									</a>

									<span class="dis-block s-text17 p-t-6">
									    <i class="fa fa-calendar"> 26 Feb 2019 </i>
									</span>
								</div>
							</li>
						</ul>					
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
