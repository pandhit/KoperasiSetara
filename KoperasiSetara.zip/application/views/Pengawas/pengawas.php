   	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url('<?php echo base_url('').'assets/'?>images/master-slide-01.jpg');">
		  
    </section>

    <section class="blog p-t-94 p-b-65" style="margin-top: -59px;">
        <div class="container">
          <div class="sec-title"style="padding-bottom:3px">
            <h3 class="m-text26 t-center"style="margin-top: 3%;margin-bottom: 2%;">
			    Dewan Pengurus
			</h3>		
		 </div>				
       </div>
    </section>
    <section class="blog p-t-94 p-b-65" style="margin-top: -11%;">
		<div class="container">
		    <div class="sec-title"style="padding-bottom:3px">	
			</div>
			<div class="row">
				<div class="card-deck">
						<div class="card shadow-lg p-3 mb-5 bg-white rounded">
									<img class="card-img-top" src="<?php echo base_url('').'assets/'?>images/blog-01.jpg" alt="Card image cap" height="239" width="200" alt="Card image cap">
									<div class="card-body">
										<h5 class="card-title" style="text-align: -webkit-center;">Nama Ketua</h5>
										<p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that </p>										
									</div>			
								</div>
								<div class="card shadow-lg p-3 mb-5 bg-white rounded">
									<img class="card-img-top" src="<?php echo base_url('').'assets/'?>images/blog-01.jpg" alt="Card image cap" height="239" width="200" alt="Card image cap">
									<div class="card-body">
										<h5 class="card-title"style="text-align: -webkit-center;">Sekretaris</h5>
										<p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that </p>
										
									</div>			
								</div>
								<div class="card shadow-lg p-3 mb-5 bg-white rounded">
									<img class="card-img-top" src="<?php echo base_url('').'assets/'?>images/blog-01.jpg" alt="Card image cap" height="239" width="200" alt="Card image cap">
									<div class="card-body">
										<h5 class="card-title"style="text-align: -webkit-center;">Bendahara</h5>
										<p class="card-text justify-center">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that</p>
										
									</div>			
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <section class="blog p-t-94 p-b-65" style="margin-top: -11%;">
        <div class="container">
          <div class="sec-title"style="padding-bottom:3px">
            <h3 class="m-text26 t-center" style="margin-top: 3%;margin-bottom: 2%;">
			    Dewan Pelaksana
			</h3>		
		 </div>				
       </div>
    </section>
    <section class="blog p-t-94 p-b-65" style="margin-top: -11%;">
		<div class="container">
		    <div class="sec-title"style="padding-bottom:3px">	
			</div>
			<div class="row">
				<div class="card-deck">
						<div class="card shadow-lg p-3 mb-5 bg-white rounded">
									<img class="card-img-top" src="<?php echo base_url('').'assets/'?>images/blog-01.jpg" alt="Card image cap" height="239" width="200" alt="Card image cap">
									<div class="card-body">
										<h5 class="card-title" style="text-align: -webkit-center;">Nama Ketua</h5>
										<p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that </p>										
									</div>			
								</div>
								<div class="card shadow-lg p-3 mb-5 bg-white rounded">
									<img class="card-img-top" src="<?php echo base_url('').'assets/'?>images/blog-01.jpg" alt="Card image cap" height="239" width="200" alt="Card image cap">
									<div class="card-body">
										<h5 class="card-title"style="text-align: -webkit-center;">Sekretaris</h5>
										<p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that </p>
										
									</div>			
								</div>
								<div class="card shadow-lg p-3 mb-5 bg-white rounded">
									<img class="card-img-top" src="<?php echo base_url('').'assets/'?>images/blog-01.jpg" alt="Card image cap" height="239" width="200" alt="Card image cap">
									<div class="card-body">
										<h5 class="card-title"style="text-align: -webkit-center;">Bendahara</h5>
										<p class="card-text justify-center">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that</p>
										
									</div>			
								</div>
							</div>
					</div>
				</div>
			</div>
		</div>
	</section>
