<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url('<?php echo base_url('').'assets/'?>images/master-slide-01.jpg');">
</section>
<section class="bgwhite p-t-60" style="margin-bottom: 35px;">
		<div class="container">
			<div class="row">
               <div class="col-lg-12">
               <div class="blog-detail-txt p-t-33">
					<h4 class="p-b-11 m-text24">
					  Kerja Sama
					</h4>								
					   <p class="p-b-25" style="text-align: justify;">
						  Kerja sama yang telah dilakukan oleh Koperasi Wanita SETARA meliputi :                                                
                          <ul compact style="font-family:sans-serif;font-size: 15px;color: #888888;margin-left:1%">
                            <li style="list-style-type: square;">
                              ASPPUK (Asosiasi Pendamping Perempuan Usaha Kecil) untuk menyalurkan dana Tagihan.
                            </li>
                            <li style="list-style-type: square;">
                               Subbag PP Dinas Sosial Pemda Klaten
                            </li>
                            <li style="list-style-type: square;"> 
                              LSM PERSEPSI Klaten
                            </li>
                            <li style="list-style-type: square;">
                               GTZ dalam program pemulihan ekonomi masyarakat korban gempa
                            </li>
                            <li style="list-style-type: square;">
                              Permodalan Nasional Madani (PNM)
                            </li>
                            <li style="list-style-type: square;">
                               Rabobank belanda
                            </li>
                          </ul>
					   </p>    
                       <br>
                       <p  class="p-b-25" style="text-align: justify;"> Meningkatnya sumber daya manusia :</p>
                       <ul style="font-family:sans-serif;font-size: 15px;color: #888888;margin-left:1%">
                        <li style="list-style-type: square;">
                             Mengadakan berbagai pelatihan untuk penguatan lembaga yang didanai oleh Hivos
                        </li>
                        <li style="list-style-type: square;">
                             Mengikuti study banding di Philipina (Regional Exposure program for leadership member), Korea (Internasional cooperative aliance), Puskowanjati (Kopwan Setya Bakti Wanita, Kopwan Kartika Candra) Jawa Timur
                        </li>
                        <li style="list-style-type: square;">
                             Mengikuti pelatihan pelatihan yang diselenggarakan oleh ASPPUK, GTZ, Deperindakop maupun depnaker.
                        </li>
                        <li style="list-style-type: square;">
                              Cooperative Development Team (CDT), FORMASI, Training Pendidikan politik IWCIP, pelatihan manajemen mini market Bhakti Mandiri Yogyakarta, Pelatihan Manajemen UKM LPM UNS.
                        </li>
                        <li style="list-style-type: square;">
                              Bekerja sama dengan Persepsi untuk pelaksanaan program PBM PPK Jateng, Program pendidikan Politik dengan PD Politik, LSM YKP Solo dalam program promosi HAK Asasi Perempuan di wilayah Klaten.
                        </li>
                        <li style="list-style-type: square;">
                             Mengikuti berbagai diskusi maupun seminar yang diselenggarakan berbagai pihak Universitas, Lembaga Swasta, Instansi Pemerintah
                        </li>
                       </ul>                          								
				   </div>	
               </div>
           </div>
		</div>
	</section>
