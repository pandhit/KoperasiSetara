<footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
		<div  class="flex-w p-b-90" style="padding-left:15%">
			
			<div class="col-lg-4  col-sm-6">
				<h4 class="s-text12 p-b-30">
					Contact Info
				</h4>

				<ul>
					<li class="p-b-9">
						<a class="text-footer" style="color:azure">
					Alamat : Jl. Raya Klaten Jatinom , Klaten Utara
						</a>
					</li>

					<li class="p-b-9">
						<a class="text-footer"  style="color:azure">
					No. Tlp : (0272) 322835
						</a>
					</li>

					<li class="p-b-9">
						<a class="text-footer" style="color:azure">
					Email :	koperasisetara@setara.com 
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="text-footer" style="color:azure">
							Find Us At Maps
						</a>
					</li>
				</ul>
			</div>

			<div class="col-lg-3  col-sm-6">
				<h4 class="s-text12 p-b-30">
					Tautan 
				</h4>
				<ul>
					<li class="p-b-9">
						<a href="#" class="text-footer">
							Tentang Kami
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="text-footer">
							Galeri
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="text-footer">
							Hubungi Kami
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="text-footer">
							Produk
						</a>
					</li>
				</ul>
			</div>

			<div class="col-lg-5 col-sm-6">
				<h4 class="s-text12 p-b-30">
					Social Media
				</h4>
					<ul>
						<span class="topbar-child1">
							<a style="color: #ffffff;font-size:23px" class="topbar-social-item fa fa-facebook"></a>				
						</span>
						<span class="topbar-child1">
						  	<a  style="color: #ffffff;font-size:23px" class="topbar-social-item fa fa-instagram"></a>				
						</span>
				  	<span class="topbar-child1">
					    	<a  style="color: #ffffff;font-size:23px" class="topbar-social-item fa fa-twitter"></a>				
						</span>		
		  	</ul>
			</div>
		</div>
</footer>
</body>
</html>