<!DOCTYPE html>
<html lang="en">
<head>
	<title>Setara Klaten</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
<link rel="icon" type="image/png" href="<?php echo base_url('assets/')?>images/logotop.png"/>
<link rel="stylesheet" href="<?php echo base_url('').'assets/'?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/themify-icons.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/icon-font.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/style.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/animate.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/hamburgers.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/animsition.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/select2.min.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/slick.css"> 
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/lightbox.min.css"> 
<link rel="stylesheet" href="<?php echo base_url('').'assets/'?>css/util.css">
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/main.css"> 
<link rel="stylesheet" href="<?php echo base_url('assets/')?>css/custom.css"> 

</head>
<body class="animsition">