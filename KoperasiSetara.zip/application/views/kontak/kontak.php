
<div style="width: 100%"><iframe width="100%" height="300" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q=Koperasi%20Setara%20Klaten+(Koperasi%20Setara%20Klaten)&amp;ie=UTF8&amp;t=&amp;z=16&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"><a href="https://www.maps.ie/map-my-route/">Create route map</a></iframe></div><br/>

	<section class="bgwhite p-t-66 p-b-60">
		<div class="container">
			<div class="row">
				<div class="col-md-8 p-b-30">
					<div class="p-r-20 p-r-0-lg">
                    <h2 class="text-sejarah-kop p-t-15 p-b-16" style="text-transform: uppercase;">
						<strong>Silakan isi form dibawah</strong>   
					</h2>
                        <div class="bo4 of-hidden size15 m-b-20">
                                <input class="sizefull txt-form p-l-22 p-r-22" type="text" name="name" placeholder="Full Name">
                        </div>
                        <div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull txt-form p-l-22 p-r-22" type="text" name="phone-number" placeholder="Phone Number">
						</div>

						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull txt-form p-l-22 p-r-22" type="text" name="email" placeholder="Email Address">
						</div>

						<textarea class="dis-block txt-form size20 bo4 p-l-22 p-r-22 p-t-13 m-b-20" name="message" placeholder="Message"></textarea>
                    </div>
                    <div class="w-size25">
							<!-- Button -->
							<button class="flex-c-m size2 bg1 hov1 m-text3 trans-0-4">
								Send
							</button>
						</div>
				</div>

				<div class="col-md-4 p-b-30">
                  <h4 class="p-t-65 p-b-34" style="margin-top: -2%;font-size: 17px;">
				    <strong style="color: #15529e;">Kontak informasi</strong>	
                  </h4>
                    <form style="margin-top: -24px;">
                        <li>
                            <p class="fa fa-building-o" style="font-size:12px;">  Jln. Klaten - Jatinom Km 1 Hargo Mulyo Gergunung, Klaten Utara.</p>
                        </li>
                        <li>
                            <p class="fa fa-phone" style="font-size:12px"> (0272) 322835</p> 
                        </li>
                        <li>
                            <p class="fa fa-envelope-o" style="font-size:12px"> setara_klaten@yahoo.com</p>
                        </li>
                    </form>
                    <h4 class="p-t-65 p-b-34" style="margin-top: -2%;font-size: 17px;">
				        <strong style="color: #15529e;">Social Media</strong>	
                  </h4>
                  <div>
                     <a href="index.html" class="fa fa-facebook" style="font-size:28px; margin-right:10px"></a>
                     <a href="index.html" class="fa fa-instagram" style="font-size:28px"></a>
                  </div>
				</div>
			</div>
		</div>
	</section>