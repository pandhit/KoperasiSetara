<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url('<?php echo base_url('').'assets/'?>images/master-slide-01.jpg');">	
	</section>

	<section class="bgwhite p-t-66 p-b-38">
		<div class="container">
			<div class="row">	           		
				<div class="col-md-12 p-b-30">
					<h2 class="text-sejarah-kop p-t-15 p-b-16" style="text-align: center;text-transform: uppercase;">
						<strong> Visi dan Misi Koperasi</strong>   
					</h2>		 
					<div class="section-line .mb-20 mb-xxs-30"></div>                  
				</div> 
			          
			</div>
		</div>
	</section>   

    <section class="bgwhite p-t-66 p-b-38" style="text-align: center;margin-top: -8%;">
		<div class="container">
			<div class="row">				
				<div class="col-md-4 p-b-30">
                    <button type="button"  data-toggle="collapse" href="#collapseExample" role="button" class="btn btn-primary active" style="width: -webkit-fill-available;border-radius: 0px;height: 50px;"><strong>Visi</strong> </button>	
                </div>               
                <div class="col-md-4 p-b-30">
                    <button type="button" data-toggle="collapse" href="#collapsemisi" role="button" class="btn btn-primary active" style="width: -webkit-fill-available;border-radius: 0px;height: 50px;"><strong>Misi</strong> </button>	
				</div>
                <div class="col-md-4 p-b-30">
                    <button type="button"  data-toggle="collapse" href="#collapsetujuan" role="button" class="btn btn-primary active" style="width: -webkit-fill-available;border-radius: 0px;height: 50px;"><strong>Tujuan</strong> </button>	
                </div>
               
         		</div>
			</div>
		</div>
    </section>
	<section style="margin-top: -22px;margin-bottom: 45px;">
	 <div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="collapse" id="collapseExample" style="text-center">							   
			<img src="<?php echo base_url('').'assets/'?>images/visi.png" alt="User Image" style="width: 60%;">
			</div>		
		</div>
    	</div>
	</section>
	<section style="margin-top: -22px;margin-bottom: 45px;">
	 <div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="collapse" id="collapsemisi" style="text-center">	
			<img src="<?php echo base_url('').'assets/'?>images/misi.png" alt="User Image" style="width: 95%;">						   			
			</div>		
		</div>
    	</div>
	</section>
	<section style="margin-top: -22px;margin-bottom: 45px;">
	 <div class="container">
		<div class="row">
			<div class="col-md-12">
			<div class="collapse" id="collapsetujuan" style="text-center">	
			<img src="<?php echo base_url('').'assets/'?>images/tujuan.png" alt="User Image" style="width: 95%;">						   			
			</div>		
		</div>
    	</div>
	</section>
