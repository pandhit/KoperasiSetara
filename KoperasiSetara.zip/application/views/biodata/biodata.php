	<section class="bg-title-page p-t-40 p-b-50 flex-col-c-m" style="background-image: url('<?php echo base_url('').'assets/'?>images/master-slide-01.jpg');">
		  
    </section>

    <section class="bgwhite p-t-66 p-b-38">
        <div class="container">
           
                <h3 class="m-text26 p-t-15 p-b-16"style="text-transform: uppercase;color: #064e83;font-size: 30px;">
				  Biodata Koperasi Setara
				</h3>	
                <ul class="keyvalue">
                    <li>  
                        <strong> Nama Koperasi </strong>  
                        <span class="notranslate"> Koperasi Setara Klaten </span>  
                    </li>
                    <li>  
                        <strong> Nama Singkat </strong>  
                        <span class="notranslate">Koperasi Setara </span>  
                    </li>
                    <li>  
                        <strong> Badan Usaha </strong>  
                        <span class="notranslate">Koperasi</span>  
                    </li>
                    <li>  
                        <strong> Bidang Usaha </strong>  
                        <span class="notranslate">Koperasi Jasa</span>  
                    </li>
                    <li>  
                        <strong> Tahun Berdiri </strong>  
                        <span class="notranslate">2000</span>  
                    </li>
                    <li>  
                        <strong> Badan Hukum </strong>  
                        <span class="notranslate">72/BH/MENEG.I/XII/2000 XXXXXXX</span>  
                    </li>
                    <li>  
                        <strong> Izin USP </strong>  
                        <span class="notranslate">294/SISP/Dep.1/XI/XXXXX</span>  
                    </li>
                    <li>  
                        <strong> TDP </strong>  
                        <span class="notranslate">XXXXXXXX</span>  
                    </li>
                    <li>  
                        <strong> SIUP </strong>  
                        <span class="notranslate">XXXXXXXX</span>  
                    </li>
                    <li>  
                        <strong> NPWP </strong>  
                        <span class="notranslate">XXXXXXXX</span>  
                    </li>
                    <li>  
                        <strong> Kantor Pusat </strong>  
                        <span class="notranslate">XXXXXXXX</span>  
                    </li>
                    <li>  
                        <strong> Telepon </strong>  
                        <span class="notranslate">XXXXXXXX</span>  
                    </li>
                    <li>  
                        <strong> Website </strong>  
                        <span class="notranslate">XXXXXXXX</span>  
                    </li>
                </ul>            
        </div>
    </section>
    <section class="blog bgwhite p-t-94 p-b-65" style="margin-top: -3%;">
		<div class="container">
			<div class="row">
				<div class="col-sm-10 col-md-4 p-b-30 m-l-r-auto">
					<!-- Block3 -->
					<div class="block3">
						<a href="blog-detail.html" class="block3-img dis-block hov-img-zoom">
							<img src="<?php echo base_url('').'assets/'?>images/shop-item-09.jpg" alt="IMG-BLOG">
						</a>
					</div>
				</div>

				<div class="col-sm-10 col-md-4 p-b-30 m-l-r-auto">
					<!-- Block3 -->
					<div class="block3">
						<a href="blog-detail.html" class="block3-img dis-block hov-img-zoom">
							<img src="<?php echo base_url('').'assets/'?>images/shop-item-09.jpg" alt="IMG-BLOG">
						</a>
					</div>
				</div>

				<div class="col-sm-10 col-md-4 p-b-30 m-l-r-auto">
					<!-- Block3 -->
					<div class="block3">
						<a href="blog-detail.html" class="block3-img dis-block hov-img-zoom">
							<img src="<?php echo base_url('').'assets/'?>images/shop-item-09.jpg" alt="IMG-BLOG">
						</a>
					</div>
				</div>
			</div>
		</div>
	</section>
